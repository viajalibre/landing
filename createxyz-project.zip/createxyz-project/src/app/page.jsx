"use client";
import React from "react";

function MainComponent() {
  const [selectedCategory, setSelectedCategory] = useState("recomendaciones");
  const [touchStart, setTouchStart] = useState(null);
  const menu = {
    recomendaciones: [
      {
        name: "Molcajete Mixto",
        price: "32.99",
        description:
          "Espectacular combinación de arrachera, pollo, chorizo, nopales y queso fundido, servido en molcajete caliente con salsa roja",
        image: "/plato-mole.jpg",
      },
      {
        name: "Chile en Nogada",
        price: "28.99",
        description:
          "Platillo tradicional poblano: chile poblano relleno de picadillo, cubierto con salsa de nuez, granada y perejil",
        image: "/plato-chiles.jpg",
      },
      {
        name: "Pescado Zarandeado",
        price: "30.99",
        description:
          "Pescado entero marinado en adobo especial de la casa, asado a la leña y servido con arroz y verduras",
        image: "/plato-ceviche.jpg",
      },
      {
        name: "Mole Ancestral",
        price: "27.99",
        description:
          "Receta familiar de mole con más de 32 ingredientes, servido con pechuga de pollo y arroz",
        image: "/plato-mole.jpg",
      },
      {
        name: "Parrillada del Chef",
        price: "45.99",
        description:
          "Selección especial de cortes de carne, chorizo, pollo y camarones a la parrilla con guarniciones",
        image: "/plato-tacos.jpg",
      },
      {
        name: "Cazuela de Mariscos",
        price: "38.99",
        description:
          "Combinación de mariscos frescos en salsa de chile guajillo, servido en cazuela de barro",
        image: "/plato-ceviche.jpg",
      },
      {
        name: "Enchiladas de Mole",
        price: "25.99",
        description:
          "Enchiladas rellenas de pollo, bañadas en mole negro oaxaqueño, decoradas con ajonjolí y crema",
        image: "/plato-enchiladas.jpg",
      },
    ],
    entradas: [
      {
        name: "Guacamole Fresco",
        price: "12.99",
        description:
          "Aguacate fresco machacado con tomate, cebolla, cilantro y un toque de limón",
        image: "/plato-tostadas.jpg",
      },
      {
        name: "Nachos Supremos",
        price: "14.99",
        description:
          "Tortillas crujientes cubiertas con frijoles refritos, queso fundido, guacamole, crema y pico de gallo",
        image: "/plato-tostadas.jpg",
      },
      {
        name: "Queso Fundido",
        price: "13.99",
        description:
          "Queso Oaxaca fundido con chorizo, champiñones y chile poblano, servido con tortillas calientes",
        image: "/plato-quesadillas.jpg",
      },
      {
        name: "Tostadas de Tinga",
        price: "11.99",
        description:
          "Tostadas crujientes topped con pollo en salsa de chipotle, lechuga, crema y queso fresco",
        image: "/plato-tostadas.jpg",
      },
      {
        name: "Empanadas de Queso",
        price: "10.99",
        description:
          "Empanadas caseras rellenas de queso Oaxaca con salsa verde fresca",
        image: "/plato-quesadillas.jpg",
      },
      {
        name: "Choriqueso",
        price: "12.99",
        description:
          "Queso fundido con chorizo español, servido con tortillas de maíz",
        image: "/plato-quesadillas.jpg",
      },
      {
        name: "Totopos con Salsa",
        price: "8.99",
        description:
          "Totopos caseros con trio de salsas: verde, roja y guacamole",
        image: "/plato-tostadas.jpg",
      },
      {
        name: "Flautas de Pollo",
        price: "11.99",
        description:
          "Tortillas doradas rellenas de pollo, servidas con lechuga, crema y queso",
        image: "/plato-tostadas.jpg",
      },
      {
        name: "Ceviche de Pescado",
        price: "15.99",
        description:
          "Pescado fresco marinado en limón con tomate, cebolla, cilantro y aguacate",
        image: "/plato-ceviche.jpg",
      },
      {
        name: "Quesadillas de Huitlacoche",
        price: "13.99",
        description:
          "Tortillas con queso y huitlacoche, servidas con salsa verde",
        image: "/plato-quesadillas.jpg",
      },
    ],
    sopas: [
      {
        name: "Sopa de Tortilla",
        price: "10.99",
        description:
          "Caldo de tomate con tortilla crujiente, aguacate, crema, queso y chile pasilla",
        image: "/plato-sopa.jpg",
      },
      {
        name: "Consomé de Pollo",
        price: "9.99",
        description:
          "Caldo de pollo casero con arroz, verduras y pollo desmenuzado",
        image: "/plato-sopa.jpg",
      },
      {
        name: "Pozole Rojo",
        price: "14.99",
        description:
          "Tradicional pozole con maíz, carne de cerdo y guarniciones",
        image: "/plato-pozole.jpg",
      },
      {
        name: "Caldo Tlalpeño",
        price: "11.99",
        description: "Caldo de pollo con garbanzos, verduras y chipotle",
        image: "/plato-sopa.jpg",
      },
      {
        name: "Sopa de Fideo",
        price: "8.99",
        description: "Fideos en caldillo de tomate con cilantro y limón",
        image: "/plato-sopa.jpg",
      },
      {
        name: "Crema de Poblano",
        price: "10.99",
        description: "Crema de chile poblano con granos de elote y croutones",
        image: "/plato-sopa.jpg",
      },
      {
        name: "Caldo de Camarón",
        price: "15.99",
        description: "Caldo picante de camarón con verduras",
        image: "/plato-sopa.jpg",
      },
      {
        name: "Sopa de Lima",
        price: "11.99",
        description: "Sopa yucateca con pollo, lima y tortilla frita",
        image: "/plato-sopa.jpg",
      },
      {
        name: "Menudo",
        price: "13.99",
        description:
          "Tradicional menudo con pata y pancita, servido con oregano y limón",
        image: "/plato-pozole.jpg",
      },
      {
        name: "Sopa Azteca",
        price: "12.99",
        description:
          "Sopa de tortilla estilo azteca con chile guajillo y epazote",
        image: "/plato-sopa.jpg",
      },
    ],
    principales: [
      {
        name: "Enchiladas Verdes",
        price: "18.99",
        description:
          "Tortillas rellenas de pollo bañadas en salsa verde con crema y queso",
        image: "/plato-enchiladas.jpg",
      },
      {
        name: "Mole Poblano",
        price: "22.99",
        description:
          "Pechuga de pollo bañada en mole poblano, servida con arroz y tortillas",
        image: "/plato-mole.jpg",
      },
      {
        name: "Chiles en Nogada",
        price: "24.99",
        description:
          "Chile poblano relleno con picadillo, cubierto de salsa de nuez y granada",
        image: "/plato-chiles.jpg",
      },
      {
        name: "Tacos al Pastor",
        price: "16.99",
        description: "Tacos de cerdo marinado con piña, cebolla y cilantro",
        image: "/plato-tacos.jpg",
      },
      {
        name: "Tamales Oaxaqueños",
        price: "15.99",
        description: "Tamales en hoja de plátano con mole negro",
        image: "/plato-tamales.jpg",
      },
      {
        name: "Cochinita Pibil",
        price: "19.99",
        description: "Cerdo adobado en achiote, cocido en hoja de plátano",
        image: "/plato-tacos.jpg",
      },
      {
        name: "Pescado a la Veracruzana",
        price: "23.99",
        description:
          "Filete de pescado en salsa de tomate, aceitunas y alcaparras",
        image: "/plato-ceviche.jpg",
      },
      {
        name: "Arrachera",
        price: "26.99",
        description:
          "Arrachera marinada a la parrilla con guacamole y frijoles charros",
        image: "/plato-tacos.jpg",
      },
      {
        name: "Mixiotes de Cordero",
        price: "24.99",
        description: "Cordero adobado cocido en mixiote con verduras",
        image: "/plato-tamales.jpg",
      },
      {
        name: "Chamorro al Horno",
        price: "25.99",
        description: "Chamorro de cerdo horneado en salsa de chile guajillo",
        image: "/plato-mole.jpg",
      },
    ],
    mariscos: [
      {
        name: "Camarones al Mojo",
        price: "27.99",
        description: "Camarones salteados en ajo y limón con arroz blanco",
        image: "/plato-ceviche.jpg",
      },
      {
        name: "Pescado Zarandeado",
        price: "28.99",
        description: "Pescado marinado en adobo especial y asado",
        image: "/plato-ceviche.jpg",
      },
      {
        name: "Pulpo a la Mexicana",
        price: "29.99",
        description: "Pulpo asado con salsa mexicana picante",
        image: "/plato-ceviche.jpg",
      },
      {
        name: "Tostadas de Atún",
        price: "21.99",
        description: "Atún fresco marinado sobre tostada con aguacate",
        image: "/plato-tostadas.jpg",
      },
      {
        name: "Sopa de Mariscos",
        price: "32.99",
        description: "Sopa rica en mariscos mixtos con verduras",
        image: "/plato-sopa.jpg",
      },
      {
        name: "Aguachile Verde",
        price: "26.99",
        description: "Camarón en salsa verde picante con pepino",
        image: "/plato-ceviche.jpg",
      },
      {
        name: "Pescado Frito",
        price: "24.99",
        description: "Pescado entero frito con arroz y ensalada",
        image: "/plato-ceviche.jpg",
      },
      {
        name: "Coctel de Camarón",
        price: "23.99",
        description: "Coctel de camarón con salsa especial y aguacate",
        image: "/plato-ceviche.jpg",
      },
      {
        name: "Empanadas de Camarón",
        price: "22.99",
        description: "Empanadas rellenas de camarón con salsa de chipotle",
        image: "/plato-quesadillas.jpg",
      },
      {
        name: "Mojarra al Mojo",
        price: "25.99",
        description: "Mojarra fresca al mojo de ajo con limón",
        image: "/plato-ceviche.jpg",
      },
    ],
    postres: [
      {
        name: "Flan Napolitano",
        price: "8.99",
        description: "Flan casero con caramelo y frutos rojos",
        image: "/plato-mole.jpg",
      },
      {
        name: "Churros con Chocolate",
        price: "7.99",
        description: "Churros calientes con salsa de chocolate y cajeta",
        image: "/plato-mole.jpg",
      },
      {
        name: "Tres Leches",
        price: "9.99",
        description: "Pastel húmedo de tres leches con crema batida",
        image: "/plato-mole.jpg",
      },
      {
        name: "Arroz con Leche",
        price: "6.99",
        description: "Arroz con leche cremoso con canela y pasas",
        image: "/plato-mole.jpg",
      },
      {
        name: "Buñuelos",
        price: "7.99",
        description: "Buñuelos crujientes con miel de piloncillo",
        image: "/plato-mole.jpg",
      },
      {
        name: "Helado Frito",
        price: "8.99",
        description: "Helado de vainilla empanizado y frito",
        image: "/plato-mole.jpg",
      },
      {
        name: "Pay de Limón",
        price: "8.99",
        description: "Pay de limón con base de galleta y merengue",
        image: "/plato-mole.jpg",
      },
      {
        name: "Plátanos Fritos",
        price: "7.99",
        description: "Plátanos fritos con crema y cajeta",
        image: "/plato-mole.jpg",
      },
      {
        name: "Carlota de Limón",
        price: "8.99",
        description: "Postre frío de galletas y limón",
        image: "/plato-mole.jpg",
      },
      {
        name: "Dulce de Calabaza",
        price: "7.99",
        description: "Calabaza en tacha con piloncillo y canela",
        image: "/plato-mole.jpg",
      },
    ],
  };
  const [currentSlide, setCurrentSlide] = useState(0);
  const slides = [
    {
      src: "/modern-restaurant-full.jpg",
      alt: "Vista panorámica de un restaurante moderno con múltiples mesas",
    },
    {
      src: "/table-multiple-dishes.jpg",
      alt: "Mesa preparada con varios platillos",
    },
    {
      src: "/plato-ceviche.jpg",
      alt: "Fresco ceviche de pescado",
    },
    {
      src: "/restaurant-interior.jpg",
      alt: "Interior acogedor del restaurante",
    },
    {
      src: "/plato-mole.jpg",
      alt: "Mole tradicional servido",
    },
    {
      src: "/dining-ambiance.jpg",
      alt: "Ambiente del comedor por la noche",
    },
  ];
  const nextSlide = () => {
    setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
  };
  const prevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
  };
  const [selectedDish, setSelectedDish] = useState(null);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    const timer = setInterval(nextSlide, 3000);
    return () => clearInterval(timer);
  }, []);

  const handleTouchStart = (e) => {
    const touch = e.touches[0];
    setTouchStart(touch.clientX);
  };
  const handleTouchMove = (e) => {
    if (!touchStart) return;
    const touch = e.touches[0];
    const diff = touchStart - touch.clientX;

    if (Math.abs(diff) > 30) {
      if (diff > 0) {
        nextSlide();
      } else {
        prevSlide();
      }
      setTouchStart(null);
    }
  };
  const handleTouchEnd = () => {
    setTouchStart(null);
  };

  return (
    <div className="min-h-screen bg-[#f8f8f8]">
      {selectedDish && showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white p-6 max-w-lg w-full">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-2xl font-roboto">{selectedDish.name}</h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <i className="fas fa-times text-xl"></i>
              </button>
            </div>
            <img
              src={selectedDish.image}
              alt={selectedDish.name}
              className="w-full h-[300px] object-cover mb-4"
            />
            <p className="text-gray-600">{selectedDish.description}</p>
            <p className="text-[#2c1810] font-bold mt-2">
              ${selectedDish.price}
            </p>
          </div>
        </div>
      )}
      <header className="bg-[#2c1810] text-white py-4">
        <div className="container mx-auto text-center">
          <img
            src="/restaurant-logo.png"
            alt="Logo de La Mesa Bonita"
            className="h-16 w-auto mb-2 mx-auto"
          />
          <h1 className="text-4xl md:text-6xl font-crimson-text">
            La Mesa Bonita
          </h1>
          <p className="text-lg font-roboto">Cocina Tradicional</p>
        </div>
      </header>

      <div className="w-full">
        <div
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          className="relative mb-12 h-[250px]"
        >
          <div className="relative h-[250px]">
            <div className="absolute inset-0">
              {slides.map((slide, index) => (
                <img
                  key={index}
                  src={slide.src}
                  alt={slide.alt}
                  className={`absolute w-full h-full object-cover transition-opacity duration-700 ${
                    index === currentSlide ? "opacity-100" : "opacity-0"
                  }`}
                />
              ))}
            </div>
            <button
              onClick={prevSlide}
              className="absolute left-4 top-1/2 -translate-y-1/2 bg-black bg-opacity-50 text-white p-4 rounded-full hover:bg-opacity-75 transition-all"
            >
              <i className="fas fa-chevron-left"></i>
            </button>
            <button
              onClick={nextSlide}
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-black bg-opacity-50 text-white p-4 rounded-full hover:bg-opacity-75 transition-all"
            >
              <i className="fas fa-chevron-right"></i>
            </button>
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-3">
              {slides.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`w-3 h-3 rounded-full transition-all ${
                    index === currentSlide
                      ? "bg-white scale-125"
                      : "bg-white/50"
                  }`}
                ></button>
              ))}
            </div>
          </div>
        </div>
        <div className="mb-12">
          <h2 className="text-3xl font-crimson-text text-center mb-8">
            Nuestro Menú
          </h2>
          <div className="relative w-full overflow-hidden mb-8">
            <div className="flex overflow-x-auto scrollbar-hide py-2 px-4 gap-2 snap-x snap-mandatory">
              {Object.keys(menu).map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-6 py-2 rounded-lg whitespace-nowrap snap-center text-shadow-sm ${
                    selectedCategory === category
                      ? "bg-[#2c1810] text-white"
                      : "bg-transparent text-[#2c1810] hover:bg-[#2c1810] hover:text-white transition-colors"
                  }`}
                >
                  <span className="font-medium">
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div className="grid gap-6 h-[500px] overflow-y-auto">
            {selectedCategory === "recomendaciones" ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {menu[selectedCategory]?.map((item, index) => (
                  <div
                    key={index}
                    className="bg-white shadow-md overflow-hidden cursor-pointer transform hover:scale-105 transition-transform"
                    onClick={() => {
                      setSelectedDish(item);
                      setShowModal(true);
                    }}
                  >
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-48 object-cover"
                    />
                    <div className="p-4">
                      <div className="flex justify-between items-center mb-2">
                        <h3 className="text-xl font-roboto text-[#2c1810]">
                          {item.name}
                        </h3>
                        <span className="text-[#2c1810] font-bold">
                          ${item.price}
                        </span>
                      </div>
                      <p className="text-gray-600 text-sm">
                        {item.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              menu[selectedCategory]?.map((item, index) => (
                <div
                  key={index}
                  className="p-4 cursor-pointer"
                  onClick={() => {
                    setSelectedDish(item);
                    setShowModal(true);
                  }}
                >
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-xl font-roboto hover:text-[#2c1810] text-shadow-sm">
                      {item.name}
                    </h3>
                    <span className="text-[#2c1810] font-bold ml-4 text-shadow-sm">
                      ${item.price}
                    </span>
                  </div>
                  <p className="text-gray-600">{item.description}</p>
                </div>
              ))
            )}
          </div>
        </div>
        <div className="bg-white p-8 rounded-lg shadow-md mb-12 text-center">
          <h2 className="text-3xl font-crimson-text mb-4">
            Horario de Atención
          </h2>
          <p className="text-gray-600 text-lg font-roboto">
            2:00 PM - 11:00 PM todos los días
          </p>
          <p className="font-roboto text-gray-600 mt-4">
            Para reservaciones llámanos al:{" "}
            <span className="font-bold">(555) 123-4567</span>
          </p>
        </div>
        <div className="w-full h-[400px] mb-12">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.1234567890123!2d-99.12345678901234!3d19.1234567890123!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTnCsDA3JzM0LjQiTiA5OcKwMDcnMzQuNCJX!5e0!3m2!1ses!2smx!4v1234567890123!5m2!1ses!2smx"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            className="rounded-lg shadow-lg"
          ></iframe>
        </div>
        <footer className="text-center mt-12">
          <div className="flex justify-center gap-6 mb-4">
            <i className="fab fa-facebook text-2xl text-[#2c1810]"></i>
            <i className="fab fa-instagram text-2xl text-[#2c1810]"></i>
            <i className="fab fa-twitter text-2xl text-[#2c1810]"></i>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default MainComponent;